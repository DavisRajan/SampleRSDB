import React, { Component } from 'react';
import axios from 'axios';
import { withRouter } from 'react-router';

const divStyle = {
  display: 'flex',
  alignItems: 'center',
  marginTop: -100
};

const panelStyle = {
  backgroundColor: 'rgba(255,255,255,0.5)',
  border: 0,
  paddingLeft: 20,
  paddingRight: 20,
  width: 300,
};




class LoginForm extends Component {
  constructor(props) {
    super(props);
    this.loginSuccess = this.loginSuccess.bind(this);
      
  }
  
  loginSuccess() {
    this.props.history.push('/login'); 
}
  handleFormSubmit() {
    axios.get('http://localhost:5000/api/hello')
    .then(res => {
      this.loginSuccess();
    })

  }

  render() {
    return (
      <div style={divStyle}>
        <div style={panelStyle}>
          <h1>Login SUccess!!!!!!!!!!</h1>
        </div>
      </div>
    )
  }
}

export default withRouter(LoginForm);

import React, { Component } from 'react';
import axios from 'axios';
import {Button } from 'react-bootstrap';

import Path from '../Candidate/CandidatePage';
import reactDom from 'react-dom';

const divStyle = {
  display: 'flex',
  alignItems: 'center',
  marginTop: -100
};

const panelStyle = {
  backgroundColor: 'rgba(255,255,255,0.5)',
  border: 0,
  paddingLeft: 20,
  paddingRight: 20,
  width: 300,
};

const buttonStyle = {
  marginBottom: 0
};


class LoginForm extends Component {
  constructor(props) {
    super(props);
  }
  
  
  handleFormSubmit() {
    axios.get('http://localhost:5000/api/hello')
    .then(res => {
      reactDom.render(<Path/>,document.getElementById("root"));
    })

  }

  render() {
    return (
      <div style={divStyle}>
        <div style={panelStyle}>
          <div horizontal className="LoginForm" id="loginForm">
            <label controlId="formEmail">
              <input type="text" placeholder="Email Address" />
            </label>
            <label controlId="formPassword">
              <input type="password" placeholder="Password" />
            </label>
            <label style={buttonStyle} controlId="formSubmit">
              <Button bsStyle="primary" type="submit" onClick={this.handleFormSubmit}>
                Login
              </Button>
            </label>
          </div>
        </div>
      </div>
    )
  }
}

export default LoginForm;

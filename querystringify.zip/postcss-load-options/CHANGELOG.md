<a name="1.2.0"></a>
# [1.2.0](https://github.com/michael-ciniawsky/postcss-load-options/compare/v1.1.0...v1.2.0) (2017-02-13)


### Features

* **index:** allow file extensions for .postcssrc ([fc15720](https://github.com/michael-ciniawsky/postcss-load-options/commit/fc15720))



<a name="1.1.0"></a>
# [1.1.0](https://github.com/michael-ciniawsky/postcss-load-options/compare/v1.0.2...v1.1.0) (2017-01-07)


### Features

* **index:** config file ([d8349b7](https://github.com/michael-ciniawsky/postcss-load-options/commit/d8349b7))




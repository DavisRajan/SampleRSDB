/* eslint strict: "off" */

module.exports = (function () {
	return this;
}());

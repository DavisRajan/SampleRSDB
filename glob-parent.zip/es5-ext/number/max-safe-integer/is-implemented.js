"use strict";

module.exports = function () {
	return typeof Number.MAX_SAFE_INTEGER === "number";
};

import React, { Component } from 'react';
import axios from 'axios';
import {Button } from 'react-bootstrap';

import CandidatePage from '../Candidate/CandidatePage';
import AdminPage from '../Admin/AdminPage';
import HRPage from '../HR/HRPage';
import ManagerPage from '../Manager/ManagerPage';

import reactDom from 'react-dom';

const divStyle = {
  display: 'flex',
  alignItems: 'center',
  marginTop: -100
};

const panelStyle = {
  backgroundColor: 'rgba(255,255,255,0.5)',
  border: 0,
  paddingLeft: 20,
  paddingRight: 20,
  width: 300,
};

const buttonStyle = {
  marginBottom: 0
};


class LoginForm extends Component {
  constructor(props) {
    super(props);
    
  }

  
  handleFormSubmit() {
    const logCred = {
      user:document.getElementById("user").value,
      pwd:document.getElementById("pwd").value
    };
    axios.post('http://localhost:5000/api/hello',logCred)
    .then(res => {
    if(res.data)
    {
     window.sessionStorage.setItem("userDetails",JSON.stringify( res.data));
      switch(res.data.result[0].UserTypeId)
      {
        // case 'ADMIN':
        // reactDom.render(<AdminPage/>,document.getElementById("root"));
        // break;
        case 1:
        reactDom.render(<CandidatePage/>,document.getElementById("root"));
        break;
        case 2:
        reactDom.render(<HRPage/>,document.getElementById("root"));
        break;
        case 3:
        reactDom.render(<ManagerPage/>,document.getElementById("root"));
        break;
      }
    }
      
    })

  }

  render() {
    return (
      <div style={divStyle}>
        <div style={panelStyle}>
          <div horizontal className="LoginForm" id="loginForm">
            <label controlId="formEmail">
              <input type="text" placeholder="Username" id="user" />
            </label>
            <label controlId="formPassword">
              <input type="password" placeholder="Password" id="pwd" />
            </label>
            <label style={buttonStyle} controlId="formSubmit">
              <Button bsStyle="primary" type="submit" onClick={this.handleFormSubmit}>
                Login
              </Button>
            </label>
          </div>
        </div>
      </div>
    )
  }
}

export default LoginForm;
